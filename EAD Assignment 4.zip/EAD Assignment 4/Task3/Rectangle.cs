﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{


    public class Rectangle
    {

        public void Area(decimal l, decimal w)
        {
            Console.WriteLine($"Area of Rectangle= {l * w}");
        }
        
        public void Perimeter(decimal l, decimal w)
        {
            Console.WriteLine($"Perimeter of Rectangle= {2*l + 2*w}");
        }
    }
}
