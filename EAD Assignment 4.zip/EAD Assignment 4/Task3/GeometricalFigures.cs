﻿using System;
using System.Collections.Generic;
using System.Text;


namespace ConsoleApp1
{

    delegate void CircleDelegate(decimal r);
    delegate void RectangleDelegate(decimal l, decimal w);

    class GeometricalFigures
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            
            Circular circle= new Circular();
            Rectangle rectangle = new Rectangle();

            CircleDelegate cir = circle.Area;
            cir += circle.Circumference;

            RectangleDelegate rec = rectangle.Area;
            rec += rectangle.Perimeter;


            cir(4);
            rec(2, 4);

        }
    }
}
