﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    public class Circular
    {
        public void Area(decimal r)
        {
            decimal pi = 3.142M;
            Console.WriteLine($"Area of Circle= {pi*(r*r)}");
        }
        
        public void Circumference(decimal r)
        {
            decimal pi = 3.142M;
            Console.WriteLine($"Circumference of Circle= {2* pi* r}");
        }

    }
}
