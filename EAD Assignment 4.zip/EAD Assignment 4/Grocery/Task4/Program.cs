﻿using Grocery_VIEW;
using System;


namespace Task4
{
    class Program
    {
        static void Main(string[] args)
        {
            GView view = new GView();
            
            view.Display();


        }
    }
}
