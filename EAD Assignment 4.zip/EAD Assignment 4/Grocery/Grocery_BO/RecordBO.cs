﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Grocery_BO
{
    public class RecordBO
    {
        public int ID { get; set; }
        public int CustomerID { get; set; }
        public int ItemID { get; set; }
        public int Quantity { get; set; }
        public decimal Bill { get; set; }
    }
}
