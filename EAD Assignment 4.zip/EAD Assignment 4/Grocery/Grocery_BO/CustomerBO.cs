﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Grocery_BO
{
    public class CustomerBO
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string PhoneNo { get; set; }
        public decimal Balance { get; set; }
        

    }
}
