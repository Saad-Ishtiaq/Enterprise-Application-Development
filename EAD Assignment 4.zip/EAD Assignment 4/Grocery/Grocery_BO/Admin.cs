﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Grocery_BO
{
    public class Admin
    {

        public string Name { get; set; }
        public string Password { get; set; }


    }
}
