﻿using System;

namespace ItemBO
{
    public class Class1
    {
    }
}
