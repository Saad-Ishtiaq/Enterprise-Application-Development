﻿using Grocery_BLL;
using Grocery_DAL;
using System;
using System.Collections.Generic;
using System.Text;

namespace Grocery_VIEW
{
    public class GView
    {
        public void Display()
        {
            Console.WriteLine("____________GOODIES Bakery_____________");
            Console.WriteLine("Select an Option");
            Console.WriteLine("1- Admin");
            Console.WriteLine("2- Customer");
            int entryChoice;
            try
            {
                entryChoice = int.Parse(Console.ReadLine());
                if (entryChoice == 1)
                {
                    GBll bll = new GBll();
                    bll.Admin();
                }
                else if (entryChoice == 2)
                {
                    GBll bll = new GBll();
                    bll.Customer();

                }
                else
                {
                    Console.WriteLine("Invalid Choice");
                }
            }
            catch
            {
                Console.WriteLine("Not valid Choice....?");

            }


        }

    }
}
