﻿using Grocery_BO;
using Grocery_DAL;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Text;

namespace Grocery_BLL
{
    public class GBll
    {
        public void Admin()
        {
            Console.WriteLine("Enter Admin Name: ");
            string adName = Console.ReadLine();
            Console.WriteLine("Enter Admin Password: ");
            string adPassword = Console.ReadLine();

            string connString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Task4;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            SqlConnection con = new SqlConnection(connString);
            con.Open();
            string query = $"Select * from Admin where AdminName=@n and Password=@p";
            SqlParameter p1 = new SqlParameter("n", adName);
            SqlParameter p2 = new SqlParameter("p", adPassword);

            SqlCommand cmd = new SqlCommand(query, con);

            cmd.Parameters.Add(p1);
            cmd.Parameters.Add(p2);
            SqlDataReader dr = cmd.ExecuteReader();
            if(dr.HasRows)
            {
                
                Console.WriteLine("Authenticated.........Access Allowed!!!");
                AdminPage();

            }
            else
            {
                Console.WriteLine("Invalid User.........Access Denied!!!");


            }

            con.Close();





        }

        public void Customer()
        {
            Console.WriteLine("Enter Customer Name: ");
            string cusName = Console.ReadLine();
            Console.WriteLine("Enter Customer Number: ");
            string cusNumber = Console.ReadLine();

            string connString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Task4;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            SqlConnection con = new SqlConnection(connString);
            con.Open();
            string query = $"Select * from customers where Name=@n and PhoneNo=@p";
            SqlParameter p1 = new SqlParameter("n", cusName);
            SqlParameter p2 = new SqlParameter("p", cusNumber);

            SqlCommand cmd = new SqlCommand(query, con);

            cmd.Parameters.Add(p1);
            cmd.Parameters.Add(p2);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                int cusID = 0;
                while (dr.Read())
                {
                    GDal dal = new GDal();
                    List<CustomerBO> clist = dal.AllCustomers();
                    foreach (CustomerBO c in clist)
                    {
                        if (c.Name.Contains(cusName))
                        {
                            cusID = System.Convert.ToInt32(c.ID);
                        }
                    }
                }

                Console.WriteLine("Authenticated.........Access Allowed!!!");
                CustomerPage(cusID);
            }
            else
            {
                Console.WriteLine("Invalid User.........Access Denied!!!");
            }

            con.Close();
        }

        private void CustomerPage(int cusID)
        {
            Console.WriteLine("\n----------------  Wellcome Dear Customer  ---------------");

            int choicek = 0;
            do
            {
                Console.WriteLine("Select an Option");
                Console.WriteLine("1- Select Items");
                Console.WriteLine("2- Pay The Bill");
                Console.WriteLine("3- Get Invoice");

                try
                {
                    Console.WriteLine("Choice: ");
                    choicek = int.Parse(Console.ReadLine());
                    Console.WriteLine(choicek);

                }
                catch
                {
                    Console.WriteLine("Invalid Choice ");
                }

                if (choicek == 1)
                {
                    FoodInverntory();

                    Console.WriteLine("Enter ID of Item to Add to the Cart");
                    int iID = 0;
                    try
                    {
                        iID = int.Parse(Console.ReadLine());
                    }
                    catch
                    {
                        Console.WriteLine("Invalid ID");
                    }
                    GDal dal = new GDal();
                    List<ItemBO> ilist = dal.Allitems();
                    if (ilist != null)
                    {
                        for (int i = 0; i < ilist.Count; i++)
                        {
                            if (ilist[i].ID == iID)
                            {
                                Console.WriteLine("Enter Quantity: ");
                                int qNeeded;
                                try
                                {
                                    qNeeded = int.Parse(Console.ReadLine());

                                    if(System.Convert.ToInt32(ilist[i].Quantity)>=qNeeded)
                                    {
                                        Console.WriteLine("Item Added");
                                        UpdateItemQuantity(iID, (ilist[i].Quantity-qNeeded));
                                        dal.AddRecord(cusID , iID, qNeeded, (qNeeded* ilist[i].Price));

                                    }
                                    else
                                    {
                                        Console.WriteLine($"Quantity needed Exceeds Stock in Hand ");
                                    }

                                }
                                catch
                                {
                                    Console.WriteLine("Invalid quantity...........");
                                }

                            }
                        }
                    }
                }



                else if (choicek == 2)
                {

                    PayBill(cusID);

                }
                else if (choicek == 3)
                {
                    GetInvoice();
                }
                
            }
            while (choicek == 1);



        }

        private void GetInvoice()
        {
            GDal dal = new GDal();
            decimal totalBill = 0M;

            List<RecordBO> rlist = dal.AllRecords();
            
            if (rlist != null)
            {
                Console.WriteLine();
                Console.WriteLine("-----------------------------------------------------------------------------------");
                Console.WriteLine("RecordID          ItemID           Customer ID        Quantity           Bill     ");
                Console.WriteLine("-----------------------------------------------------------------------------------");

                for (int i = 0; i < rlist.Count; i++)
                {
                    Console.WriteLine($"{rlist[i].ID,-10} " +
                                      $"{rlist[i].CustomerID,10} " +
                                      $"{rlist[i].ItemID,20} " +
                                      $"{rlist[i].Quantity,15}" +
                                      $"{rlist[i].Bill,15:C}");

                    totalBill += rlist[i].Bill;
                }
                Console.WriteLine("----------------------------------------------------------------------------------");
            }

            Console.WriteLine($"                                                                           {totalBill:C}");
        }

        private void PayBill(int cusID)
        {
            GDal dal = new GDal();
            decimal totalBill = 0M;

            List<RecordBO> rlist = dal.AllRecords();
            if (rlist != null)
            {
                Console.WriteLine();
                Console.WriteLine("-----------------------------------------------------------------------------------");
                Console.WriteLine("RecordID          CustomerID           ItemID        Quantity           Bill     ");
                Console.WriteLine("-----------------------------------------------------------------------------------");

                
                for (int i = 0; i < rlist.Count; i++)
                {

                    if (cusID == rlist[i].CustomerID)
                    {
                        Console.WriteLine($"{rlist[i].ID,-10} " +
                                          $"{rlist[i].CustomerID,10} " +
                                          $"{rlist[i].ItemID,20} " +
                                          $"{rlist[i].Quantity,15}"+
                                          $"{rlist[i].Bill,15:C}");

                        totalBill += rlist[i].Bill;
                    }
                }
                Console.WriteLine("----------------------------------------------------------------------------------");
            }



            UpdateCustomerBalance(cusID,totalBill);
            Console.WriteLine("Bill Paid!!!");

        }

        private void UpdateCustomerBalance(int iID, decimal totalBill)
        {
            GDal dal = new GDal();
            List<CustomerBO> ilist = dal.AllCustomers();
            if (ilist != null)
            {
                for (int i = 0; i < ilist.Count; i++)
                {
                    if (ilist[i].ID == iID)
                    {

                        CustomerBO item = new CustomerBO();
                        item = ilist[i];
                        item.Balance = item.Balance-totalBill;


                        dal.UpdateCustomer(item);

                    }
                }
            }
        }

        private void AdminPage()
        {
            Console.WriteLine("\n----------------  Wellcome Admin  ---------------");
            int choice = 0;
            do
            {
                Console.WriteLine("Select an Option");
                Console.WriteLine("1- Add Item");
                Console.WriteLine("2- Update Item");
                Console.WriteLine("3- Delete Item");
                Console.WriteLine("4- Records ");
                Console.WriteLine("5- FoodInventoryDetials ");
                Console.WriteLine("6- Exit");

                try
                {
                    choice = int.Parse(Console.ReadLine());
                    
                }
                catch
                {
                    Console.WriteLine("Invalid Choice ");
                }

                if (choice == 1)
                {
                    AddItem();
                }
                if (choice == 2)
                {
                    UpdateItem();
                }
                if (choice == 3)
                {
                    DeleteItem();
                }
                if (choice == 4)
                {
                    Record();
                }
                if (choice == 5)
                {
                    FoodInverntory();
                }


            }
            while (choice != 6);
        }

        private void Record()
        {
            GDal dal = new GDal();
            List<RecordBO> rlist = dal.AllRecords();
            if (rlist != null)
            {
                Console.WriteLine();
                Console.WriteLine("-----------------------------------------------------------------------------------");
                Console.WriteLine("RecordID          CustomerID           ItemID        Quantity           Bill     ");
                Console.WriteLine("-----------------------------------------------------------------------------------");

                for (int i = 0; i < rlist.Count; i++)
                {
                    Console.WriteLine($"{rlist[i].ID,-10} " +
                                      $"{rlist[i].CustomerID,10} " +
                                      $"{rlist[i].ItemID,20} " +
                                      $"{rlist[i].Quantity,15}" +
                                      $"{rlist[i].Bill,15:C}");

                }
                Console.WriteLine("----------------------------------------------------------------------------------");
            }
        }

        private void FoodInverntory()
        {
            GDal dal = new GDal();
            List<ItemBO> ilist = dal.Allitems();
            if (ilist != null)
            {
                    Console.WriteLine();
                    Console.WriteLine("--------------------------------------------------------------------");
                    Console.WriteLine("ItemID           Description        Price            Quantity     ");
                    Console.WriteLine("-------------------------------------------------------------------");

                for (int i = 0; i < ilist.Count; i++)
                {
                    Console.WriteLine($"{ilist[i].ID,-10} " +
                                      $"{ilist[i].Description,18}" +
                                      $"{ilist[i].Price,15:C}" +
                                      $"{ilist[i].Quantity,15}");

                }
                    Console.WriteLine("------------------------------------------------------------------");
            }
        }

        private void DeleteItem()
        {
            Console.WriteLine("Enter ID of Item: ");
            int iID = 0;
            try
            {
                iID = int.Parse(Console.ReadLine());
            }
            catch
            {
                Console.WriteLine("Invalid ID");
            }
            GDal dal = new GDal();
            dal.DeleteItem(iID);

        }


        private void UpdateItemQuantity(int iID, int uQuan)
        {
            GDal dal = new GDal();
            List<ItemBO> ilist = dal.Allitems();
            if (ilist != null)
            {
                for (int i = 0; i < ilist.Count; i++)
                {
                    if (ilist[i].ID == iID)
                    {

                        ItemBO item = new ItemBO();
                        item = ilist[i];
                        item.Quantity = uQuan;
                        

                        dal.UpdateItem(item);

                    }
                }
            }
        }



        private void UpdateItem()
        {
            Console.WriteLine("Enter ID of Item: ");
            int iID=0;
            try
            {
                iID = int.Parse(Console.ReadLine());
            }
            catch
            {
                Console.WriteLine("Invalid ID");
            }
            GDal dal = new GDal();
            List<ItemBO> ilist=dal.Allitems();
            if (ilist != null)
            {
                for(int i=0;i<ilist.Count;i++)
                {
                    if(ilist[i].ID==iID)
                    {
                        
                        Console.WriteLine("Enter Updated Description");
                        string udes = Console.ReadLine();

                        Console.WriteLine("Enter Updated Price");
                        decimal upric = 0M;
                        try
                        {
                            upric = int.Parse(Console.ReadLine());
                        }
                        catch
                        {
                            Console.WriteLine("Not Valid Price");
                        }
                        Console.WriteLine("Enter Updated Quantity");
                        int uQuan = 0;
                        try
                        {
                            uQuan = int.Parse(Console.ReadLine());
                        }
                        catch
                        {
                            Console.WriteLine("Not Valid Quantity");
                        }

                        ItemBO item = new ItemBO();
                        item = ilist[i];
                        if (udes.Length!=0)
                        {
                            item.Description = udes;
                        }
                        if (upric!=0M)
                        {
                            item.Price = upric;
                        }
                        if (uQuan != 0)
                        {
                            item.Quantity = uQuan;
                        }

                        dal.UpdateItem(item);

                    }
                }
            }


        }

        private void AddItem()
        {
            ItemBO item = new ItemBO();

            Console.WriteLine("Enter Item Description: ");
            item.Description = Console.ReadLine();
            decimal iPrice = 0M;
            int iQuantity = 0;

            Console.WriteLine("Enter Item Price: ");
            try
            {
                iPrice =decimal.Parse( Console.ReadLine());
            }
            catch
            {
                Console.WriteLine("Not Valid Price");
            }

            Console.WriteLine("Enter Item Quantity: ");
            try
            {
                iQuantity = int.Parse(Console.ReadLine());
            }
            catch
            {
                Console.WriteLine("Not Valid Quantity");
            }

            item.Price = iPrice;
            item.Quantity = iQuantity;

            GDal dal = new GDal();
            dal.Additem(item);

        }
    }
}
