﻿using Grocery_BO;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Text;

namespace Grocery_DAL
{
    public class GDal
    {
        public void Additem(ItemBO item)
        {
            string conString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Task4;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            SqlConnection connection = new SqlConnection(conString);
            
            string query = $"insert into items (description, price, quantity)" +
                $"  values(@d,@p,@q)";

            SqlParameter d = new SqlParameter("d", item.Description);
            SqlParameter p = new SqlParameter("p", item.Price);
            SqlParameter q = new SqlParameter("q", item.Quantity);

            SqlCommand cmd = new SqlCommand(query, connection);

            cmd.Parameters.Add(d);
            cmd.Parameters.Add(p);
            cmd.Parameters.Add(q);
            
            connection.Open();
            int insertedRows = cmd.ExecuteNonQuery();
            if (insertedRows >= 1)
            {
                Console.WriteLine("row inserted/updated/deleted");
            }
            else
            {
                Console.WriteLine("failed");
            }
            connection.Close();

        }

        public List<ItemBO> Allitems()
        {
            string connString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Task4;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            SqlConnection con = new SqlConnection(connString);
            con.Open();

            string query = $"Select * from items";
            
            SqlCommand cmd = new SqlCommand(query, con);

            List<ItemBO> ilist = new List<ItemBO>();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                ItemBO item=new ItemBO();
                item.ID = System.Convert.ToInt32(dr[0]);
                item.Description = dr[1].ToString();
                item.Price = System.Convert.ToDecimal(dr[2]);
                item.Quantity =System.Convert.ToInt32( dr[3]);

                ilist.Add(item);
            }
            con.Close();

            return ilist;
        }

        public void UpdateItem(ItemBO item)
        {
            string conString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Task4;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            SqlConnection connection = new SqlConnection(conString);

            string query = $"update items set description=@d , price=@p , quantity=@q where id=@i";

            SqlParameter i = new SqlParameter("i", item.ID);
            SqlParameter d = new SqlParameter("d", item.Description);
            SqlParameter p = new SqlParameter("p", item.Price);
            SqlParameter q = new SqlParameter("q", item.Quantity);

            SqlCommand cmd = new SqlCommand(query, connection);

            cmd.Parameters.Add(i);
            cmd.Parameters.Add(d);
            cmd.Parameters.Add(p);
            cmd.Parameters.Add(q);

            connection.Open();
            int insertedRows = cmd.ExecuteNonQuery();
            if (insertedRows >= 1)
            {
                Console.WriteLine("row inserted/updated/deleted");
            }
            else
            {
                Console.WriteLine("failed");
            }
            connection.Close();


        }

        public void DeleteItem(int id)
        {
            string conString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Task4;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            SqlConnection connection = new SqlConnection(conString);
            string query = $"delete from items where id=@u";
            SqlParameter p1 = new SqlParameter("u", id);
            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.Add(p1);
            connection.Open();
            cmd.ExecuteNonQuery();
            

            connection.Close();


        }

        public void AddRecord(int cusID, int itemID, int Quantity, decimal bill)
        {
            string conString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Task4;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            SqlConnection connection = new SqlConnection(conString);
            string query = $"insert into Records (CustomerID, ItemID, Quantity, Bill)" +
                $"  values(@c,@i,@q,@b)";
            SqlParameter p1 = new SqlParameter("c", cusID);
            SqlParameter p2 = new SqlParameter("i", itemID);
            SqlParameter p3 = new SqlParameter("q", Quantity);
            SqlParameter p4 = new SqlParameter("b", bill);
            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.Add(p1);
            cmd.Parameters.Add(p2);
            cmd.Parameters.Add(p3);
            cmd.Parameters.Add(p4);
            connection.Open();
            int insertedRows = cmd.ExecuteNonQuery();
            if (insertedRows >= 1)
            {
                Console.WriteLine("row inserted/updated/deleted");
            }
            else
            {
                Console.WriteLine("failed");
            }
            connection.Close();





        }

        public List<RecordBO> AllRecords()
        {

            Console.WriteLine("Accessing Records..");

            string connString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Task4;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            SqlConnection con = new SqlConnection(connString);
            con.Open();

            string query = $"Select * from Records";

            SqlCommand cmd = new SqlCommand(query, con);
            
            List<RecordBO> ilist = new List<RecordBO>();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                RecordBO record = new RecordBO();
                record.ID = System.Convert.ToInt32(dr[0]);
                record.CustomerID = System.Convert.ToInt32(dr[1]);
                record.ItemID = System.Convert.ToInt32(dr[2]);
                record.Quantity = System.Convert.ToInt32(dr[3]);
                record.Bill = System.Convert.ToDecimal(dr[4]);
                ilist.Add(record);
            }

            foreach (RecordBO r in ilist)
            {
                Console.WriteLine("Hello");
                Console.WriteLine(r.Bill.ToString());

            }


            con.Close();
            return ilist;

        }

        public List<CustomerBO> AllCustomers()
        {
            string connString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Task4;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            SqlConnection con = new SqlConnection(connString);
            con.Open();

            string query = $"Select * from customers";

            SqlCommand cmd = new SqlCommand(query, con);

            List<CustomerBO> ilist = new List<CustomerBO>();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                CustomerBO item = new CustomerBO();
                item.ID = System.Convert.ToInt32(dr[0]);
                item.Name = dr[1].ToString();
                item.PhoneNo = dr[2].ToString();
                item.Balance = System.Convert.ToDecimal(dr[3]);

                ilist.Add(item);
            }
            con.Close();

            return ilist;
        }

        public void UpdateCustomer(CustomerBO item)
        {
            string conString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Task4;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            SqlConnection connection = new SqlConnection(conString);

            string query = $"update customers set balance=@p where id=@i";

            SqlParameter i = new SqlParameter("i", item.ID);
            SqlParameter p = new SqlParameter("p", item.Balance);

            SqlCommand cmd = new SqlCommand(query, connection);

            cmd.Parameters.Add(i);
            cmd.Parameters.Add(p);

            connection.Open();
            int insertedRows = cmd.ExecuteNonQuery();
            if (insertedRows >= 1)
            {
                Console.WriteLine("row inserted/updated/deleted");
            }
            else
            {
                Console.WriteLine("failed");
            }
            connection.Close();

        }
    }
}
